# Team04
### **Ameya Pandit / Matthew Dunn  / Richard Duong  /  Xingjian Qu  / Yuming Wang  / Yunhe Shao /**
### Date: 2/1/2019
------
#### This is the final release of our Chess Program for Project 1 in EECS22L Winter.

To install, please type "make" into your terminal and enjoy the gameplay experience. For more detailed instructions on installation, gameplay, etc. please refer to the User Manual with the link below.

#### Modules that are currently working:
  Player vs. Player

  Player vs. Computer

  Computer vs. Computer

  Undo moves

#### Avaliable features
  AI based Hint

  3 levels of difficulties ---- Easy, Medium and Hard

  Custom board setup

##### All of these features can been seen and choose during menu page and during gameplay

#### GUI sections
  Finished a GUI Board with all pieces moveable

  Finised a basic GUI menu page

#### Developing on
  More complete menu page

  Linking GUI board modual with functions

  Linking GUI board with GUI menu page



#### Links
  ![User Manual](https://github.uci.edu/19WEECS22L/Team04/blob/master/doc/Install.txt)




  Copyright © 2019 DeepCoreDumped Team. All rights reserved.
