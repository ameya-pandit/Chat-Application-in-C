README Author: Ameya Pandit
Team04 Teammates: Matthew Dunn, Richard Duong, Xingjian Qu, Yuming Wang, Yunhe Shao
Date: 2/1/2019

This is Team04's Alpha Release for their Chess game! To install, please type "make" into your terminal and enjoy the gameplay experience. For more detailed instructions on installation, gameplay, etc. please refer to the User Manual. We hope you enjoy this gaming experience!

Modules that are not currently working:
Player vs. Computer
Computer vs. Computer
Undo moves functionality
